from .shape import Rectangle, Point, Square, Triangle
